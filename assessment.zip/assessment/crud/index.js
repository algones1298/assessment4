const express = require('express');
const path = require('path');
const Datastore = require('nedb');
const { error } = require('console');
const app = express();

const db = new Datastore({ filename: 'data/crud', autoload: true });


 app.set('views', path.join(__dirname, 'views'));
 app.set('view engine', 'hbs');

// midldlewares 
app.use(express.urlencoded({extended: false}))
 // static files ( images, Css, Js(frontend) files )
app.use(express.static(path.join(__dirname, 'public')));

// routes
app.get('/', (req, res) => {
  db.find({ },(error, docs) => {
    if (error) console.log(error);
    res.render('index', {data: docs});
  });
  });


// app post
app.post('/create',(req, res) => {
  const doc = {
    todo: req.body.todo
  }
  db.insert(doc, (eror) => {})
  if (error) console.log(error);
  res.redirect('/');
});

app.get('/todo/update/:id',(req, res) => {
  db.find({_id: req.params.id},(error, docs) => {
    // if (error) console.log(error);
  res.render('update', {data: docs[0]});
});
});

app.post('/todo/update/:id', (req, res) => {
  db.update(
    { _id: req.params.id },
    {$set: {todo: req.body.todo}},
     {},
    (error) => {
      // if (error) console.log(error);
      res.redirect('/');
    }
  )

});

app.post('/todo/delete/:id', (req, res) => {
  db.remove({_id: req.params.id}, {}, (error) => {
    // if (error) console.log(error);
    res.redirect('/');
  });
});

app.listen(3000);