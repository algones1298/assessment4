const express = require('express');
const path = require('path');
const app = express();

 app.set('views', path.join(__dirname, 'views'));
 app.set('view engine', 'hbs');

 // static files ( images, Css, Js(frontend) files )
 app.use(express.static(path.join(__dirname, 'public')));


// routes
app.get('/', (req, res) => {
  res.render('index');
});


app.listen(3000);






// to kill process = ctrl + C
// to run process = node index.js but i change it to nodemon so i only type npm run start