const express = require('express');
const path = require('path');
const Datastore = require('nedb');

const app = express();
const db = new Datastore({ filename: 'data/signup', autoload: true });



 app.set('views', path.join(__dirname, 'views'));
 app.set('view engine', 'hbs');

 // static files ( images, Css, Js(frontend) files )
 app.use(express.static(path.join(__dirname, 'public')));
 // midldlewares 
 app.use(express.urlencoded({extended: false}))


// routes
app.get('/', (req, res) => {
  res.render('login',);
});

app.get('/signup', (req, res) => {
  res.render('signup',);
});

app.get('/home', (req, res) => {
  res.render('home',);
});


// post
app.post('/signup', (req,res) => {

  const name = req.body.name
  const username = req.body.username
  const password = req.body.password
  const email =  req.body.email

  const doc = {name: name,username: username, email: email, password: password};

  db.insert(doc,(err,docs) => {
    // if user exist, redirect to login
    // if user exist, redicrect to home
    if (docs.length > 0){
      console.log('successful login');
      data.find('username', docs[0].username);
      res.redirect('/');
    }else{
      console.log('Successful login');
      res.redirect('/home');
    }
  })
});

app.post('/login', (req,res) => {

  const username = req.body.username
  const password = req.body.password

  const doc = {username: username, password: password};
  
    db.find(doc,(err,docs) => {
      // if user exist, redirect to home
      // if not, redirect back to login
      if (docs.length > 0){
        console.log('successful login');
        res.redirect('home');
      }else{
        console.log('invalid credentials');
        res.redirect('/login');
      }
    })
});


app.listen(3000);